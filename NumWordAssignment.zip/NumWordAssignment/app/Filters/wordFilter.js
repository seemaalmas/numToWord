//filter for to show data in word format on the web page
	app.filter('convertToWords', function() {
	  function isInteger(x) {
			return x % 1 === 0;
		}

	  return function(value) {
		if (value){
		  return  valueWithDecimal(value);
	  }
		return value;
	  };

	});